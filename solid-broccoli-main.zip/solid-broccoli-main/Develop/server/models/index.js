const User = require('./User');

module.exports = { User };
